export { formatProductTenure } from './product-tenure';
export {
  formatAmount,
  formatCurrency,
  formatInterest,
  formatPercentage,
  formatRate,
  formatTenure,
} from './format';
export {
  describeActiveFilters,
  facetLabel,
  facetValueLabel,
  facetValueLongLabel,
  type ActiveFilterDescriptor,
  type MarketplaceFilterKey,
} from './filter-labels';
export {
  createAmountSchema,
  parseCalculatorAmount,
  parseDepositAmount,
  type CalculatorAmountResult,
} from './calculator-input';
export {
  bestQualifier,
  buildCompareRows,
  isBestCell,
  NO_VALUE,
  STACKED_COMPARE_ROWS,
} from './compare-rows';
export { addLabel, removeLabel, selectLabel } from './compare-labels';
export {
  compareHref,
  IDS_PARAM,
  mergeCompareParams,
  parseCompareIds,
  serialiseCompareIds,
} from './compare-url';
export { toProductListParams } from './list-params';
export { selectProductPreview } from './product-preview';
export { mergeMarketplaceParams, parseMarketplaceUrlValues } from './url-values';
export { calculateInterestEarned, calculateMaturity } from './maturity';
/** Canonical implementation is `@/utils/finance` (R1 step 2). Re-exported for existing callers. */
export { resolveApplicableRate } from '@/utils/finance';
